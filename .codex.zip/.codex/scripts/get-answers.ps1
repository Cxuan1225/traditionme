param(
    [Parameter(Mandatory = $true)]
    [ValidateSet('backend', 'frontend', 'qa', 'docs')]
    [string]$Agent,

    [switch]$Watch,
    [int]$IntervalSeconds = 5,
    [switch]$Keep
)

$baseDir = Join-Path $PSScriptRoot '..\\coordination'
$outgoingDir = Join-Path $baseDir 'answers\\outgoing'
$consumedDir = Join-Path $baseDir 'answers\\consumed'
$logsDir = Join-Path $baseDir 'logs'
$logFile = Join-Path $logsDir ("answers-$Agent.log")

function Write-Log {
    param([string]$Message)
    $line = "[$([DateTime]::Now.ToString('s'))] $Message"
    Add-Content -Path $logFile -Value $line
    Write-Output $line
}

function Parse-Frontmatter {
    param([string]$Text)
    $meta = @{}
    if (-not $Text.StartsWith('---')) { return $meta }

    $lines = $Text -split "`r?`n"
    $i = 1
    while ($i -lt $lines.Length) {
        $line = $lines[$i]
        if ($line -eq '---') { break }
        if ($line -match '^([A-Za-z0-9_\-]+):\s*(.*)$') {
            $meta[$matches[1].ToLower()] = $matches[2]
        }
        $i++
    }

    return $meta
}

function Print-Answer {
    param([string]$Path)

    try {
        $text = Get-Content -Path $Path -Raw
        $meta = Parse-Frontmatter -Text $text
        $to = $meta['to']

        if ($to -ne $Agent) {
            return
        }

        Write-Output ""
        Write-Output "=== ANSWER: $($meta['id']) ==="
        Write-Output $text

        if (-not $Keep.IsPresent) {
            Move-Item -Path $Path -Destination (Join-Path $consumedDir ([IO.Path]::GetFileName($Path))) -Force
            Write-Log "Consumed answer: $($meta['id'])"
        }
    } catch {
        Write-Log "Error reading answer file $Path : $($_.Exception.Message)"
    }
}

while ($true) {
    try {
        $files = Get-ChildItem -Path $outgoingDir -File -Filter '*.md' -ErrorAction SilentlyContinue | Sort-Object LastWriteTime
        foreach ($file in $files) {
            Print-Answer -Path $file.FullName
        }
    } catch {
        Write-Log "Answer watch loop error: $($_.Exception.Message)"
    }

    if (-not $Watch.IsPresent) {
        break
    }

    Start-Sleep -Seconds $IntervalSeconds
}
