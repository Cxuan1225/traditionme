## Coordination
LOCK: none
RESUME FROM: orchestrator-auto-2026-03-01T05:02:19
SUBTASK STATUS: blocked
LAST UPDATED: 2026-02-28

## Task
RBAC admin UI using Wayfinder (consume backend matrix contract)

## Scope
`resources/js/`, `resources/css/`

## Files
- `.codex/tasks/rbac-admin-user-seller-matrix-and-frontend-admin.md`
- `resources/js/Pages/**` (RBAC admin pages/components)
- `resources/js/routes/**`, `resources/js/actions/**` (consumption only; no raw URL literals)

## Routes (if any)
- consume backend-provided contract; list used route/action modules in results

## Commands Run
- `npx eslint resources/js/pages/settings/security/Roles.vue`
- `npm run types:check`
- `npm run lint:check` (repository-level run, fails due pre-existing `vitepress/docs/.vitepress/dist/**` generated files and unrelated config parsing; new RBAC page has no lint errors)

## Results
- Added `resources/js/pages/settings/security/Roles.vue` RBAC admin UI using `<script setup lang="ts">`.
- Implemented role/permission listing via Wayfinder route module `@/routes/security/roles`.
- Implemented role creation via Wayfinder action module `@/actions/App/Http/Controllers/Security/RoleController`.
- Implemented role-permission sync via Wayfinder action module `@/actions/App/Http/Controllers/Security/RolePermissionController`.
- Implemented user-role assignment via Wayfinder action module `@/actions/App/Http/Controllers/Security/UserRoleController`.
- Added permission-aware UI controls through optional capability props (`canViewRoles`, `canCreateRoles`, `canManageRolePermissions`, `canAssignUserRoles`) with safe defaults.
- No hard-coded URL strings were introduced in Vue/TS.

## Open Issues
- Backend currently exposes `security.roles.index` as JSON only. This frontend page is ready to be rendered by an Inertia route/page contract (or controller branch) without further frontend changes.

## Orchestrator Notes
- Frontend starts implementation once backend confirms role/permission contract and any route/action updates.
- Must use `<script setup lang="ts">`, Composition API, and Wayfinder-generated modules.
- No hard-coded URLs in Vue/TS.

### Handoff -> frontend
**Task:** rbac-admin-ui-wayfinder
**Stage:** implement
**Context:** Build RBAC management screens for roles/permissions/user-role assignment against backend security endpoints and resource payloads.
**Acceptance criteria:** Admin flow supports listing roles and permission state, syncing role permissions, and assigning user roles; permission-aware UI behavior is implemented.

## Next Step
start after backend contract confirmation, then handoff to orchestrator for QA

### Handoff -> orchestrator
**Task:** rbac-admin-ui-wayfinder
**Stage:** implement
**Context:** Frontend implementation is complete at `resources/js/pages/settings/security/Roles.vue` and validated with file-level lint + TS checks. Blocker: backend currently returns JSON for `security.roles.index` and does not yet expose/confirm the Inertia render contract for page `settings/security/Roles`.
**Acceptance criteria:** Orchestrator coordinates backend to provide/confirm Inertia page rendering and capability props wiring, then routes task to QA for full verification.
